const n=new Set(["pendiente","agendada","confirmada","tentativa"]);function t(e){return e?n.has(e.trim().toLowerCase()):!1}export{t as i};
